"""
Your module description
"""
myfruitlist = ["apple", "banana", "cherry"]
print(myfruitlist)
print(type(myfruitlist))

print(myfruitlist[0])
print(myfruitlist[1])
print(myfruitlist[2])

myfruitlist[2] = "orange"
print(myfruitlist)
myfinalAnswerTuple = ("apple", "banana", "pineapple")
print(myfinalAnswerTuple)
print(type(myfinalAnswerTuple))

print(myfinalAnswerTuple[0])
print(myfinalAnswerTuple[1])
print(myfinalAnswerTuple[2])

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])
